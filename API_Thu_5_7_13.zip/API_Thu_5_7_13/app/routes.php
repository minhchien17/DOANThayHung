<?php
declare(strict_types=1);

use App\Application\Actions\User\ListUsersAction;
use App\Application\Actions\User\ViewUserAction;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\App;
use Slim\Interfaces\RouteCollectorProxyInterface as Group;

return function (App $app) {
    $app->options('/{routes:.*}', function (Request $request, Response $response) {
        // CORS Pre-Flight OPTIONS Request Handler
        return $response;
    });

    $app->get('/', function (Request $request, Response $response) {
        $response->getBody()->write('Hello world!');
        return $response;
    });

    $app->group('/users', function (Group $group) {
        $group->get('', ListUsersAction::class);
        $group->get('/{id}', ViewUserAction::class);
    });
	$app->get('/todos', function ($request,$response,$args){
		$sth=$this->db->prepare("SELECT * FROM tasks ORDER BY tasks");
		$sth->execute();
		$todo=$sth->fetchAll();
		return $this->response->withJson($todos);
	});
	$app->get('/todos/search/[{query}]', function ($request,$response,$args){
		$sth=$this->db->prepare("SELECT * FROM tasks where UPPER(tasks) LIKE : query ORDER BY task");
		$query="%".$args['query']."%";
		$sth->bindParam("query",$query);
		$sth->execute();
		$todo=$sth->fetchAll();
		return $this->response->withJson($todos);
	});
	
	 // Add a new todo
	 $app->post('/todo', function ($request, $response) {
			$input = $request->getParsedBody();
			$sql = "INSERT INTO tasks (task) VALUES (:task)";
	 $sth = $this->db->prepare($sql);
			$sth->bindParam("task", $input['task']);
	 $sth->execute();
	 $input['id'] = $this->db->lastInsertId();
		 return $this->response->withJson($input);
	 });
	 
	// DELETE a todo with given id
	 $app->delete('/todo/[{id}]', function ($request, $response, $args) {
	 $sth = $this->db->prepare("DELETE FROM tasks WHERE id=:id");
			$sth->bindParam("id", $args['id']);
	 $sth->execute();
	 $todos = $sth->fetchAll();
		 return $this->response->withJson($todos);
	 });
};